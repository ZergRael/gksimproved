GKSsimproved
===========

Améliore et facilite la navigation sur certaines parties de gks.gs

Voir topic associé.

TODO.list
- Moar comments
- Améliorer les options
- Optimisations
- Amélioration de la charge CPU (pré-parsing / insertion blocs)

TODO.done
- BugFix: Coloration de multiples twits sur un seul message
- Optimisations - CPU sur filtrage
- Moar comments
- Gestion des headers de pages torrents en endless scrolling
- Bouton pour remonter en haut de page sur l'endless scrolling
- Auto-complétion twits à l'édition des posts
- Coloration des twits après édition d'un post
- Migration Github